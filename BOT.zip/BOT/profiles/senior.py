# profiles/senior.py
import asyncio
import random
from config import TARGET_URL
from utils import install_visual_cursor, smooth_click_element, human_type, smooth_scroll, scroll_to_top, smooth_mouse_and_click, force_navigate_to_target

async def profile_senior(page, dane):
    print("\n---> [Uruchamiam] Profil: Senior (Powolny i ostrożny)")
    await page.goto(TARGET_URL, wait_until="domcontentloaded")
    await asyncio.sleep(4) 
    await install_visual_cursor(page)

    try:
        home_url = await page.evaluate("window.location.origin")
        print(f"[*] Senior wchodzi na stronę główną: {home_url}")
        await page.goto(home_url, wait_until="domcontentloaded")
        await asyncio.sleep(random.uniform(5.0, 8.0))
        await install_visual_cursor(page)
        
        print("[*] Ogląda stronę bardzo powoli...")
        await smooth_mouse_and_click(page, actions=random.randint(3, 5))
        await smooth_scroll(page, scrolls=random.randint(1, 3)) # Krótko, bo się gubi
        await asyncio.sleep(random.uniform(3.0, 6.0))
            
        await scroll_to_top(page)
        await force_navigate_to_target(page)
        await install_visual_cursor(page)
        
    except Exception as e:
        print(f"[!] Błąd w fazie błądzenia: {e}")
        await force_navigate_to_target(page)
        await install_visual_cursor(page)

    try:
        await asyncio.sleep(random.uniform(3.0, 5.0))
        print("[*] Senior szuka opcji rejestracji...")
        await smooth_mouse_and_click(page, actions=2)
        await smooth_click_element(page, 'label[for="registration"]')
        await asyncio.sleep(random.uniform(3.0, 5.0))

        # Ekstremalnie wolne pisanie
        print("[*] Wpisywanie e-maila jednym palcem...")
        await human_type(page, "#dwfrm_registrationaccount_email", dane["email"], mistake_rate=0.08, typing_speed=(300, 600))
        await asyncio.sleep(random.uniform(2.0, 4.0))
        
        print("[*] Szukanie znaków na klawiaturze przy haśle...")
        await human_type(page, "input[id^='dwfrm_registrationaccount_password_']", dane["haslo"], mistake_rate=0.1, typing_speed=(350, 700))
        
        print("[*] Niepewność przy zgodach...")
        await smooth_mouse_and_click(page, actions=3)
        await asyncio.sleep(random.uniform(3.0, 6.0)) 
        
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_pmtc"]')
        await asyncio.sleep(random.uniform(2.0, 4.0)) 
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_addtoemaillist"]')
        await asyncio.sleep(random.uniform(2.0, 4.0))

        await smooth_click_element(page, 'button[name="dwfrm_profile_confirm"]')

        await page.wait_for_selector("#dwfrm_registrationcontact_firstName", state="visible", timeout=20000)
        await asyncio.sleep(random.uniform(4.0, 6.0)) 

        print("[*] Senior wypełnia dane...")
        await human_type(page, "#dwfrm_registrationcontact_firstName", dane["imie"], mistake_rate=0.1, typing_speed=(300, 500))
        await asyncio.sleep(random.uniform(2.0, 3.5))
        await human_type(page, "#dwfrm_registrationcontact_lastName", dane["nazwisko"], mistake_rate=0.1, typing_speed=(300, 500))

        await asyncio.sleep(random.uniform(2.0, 4.0))
        await human_type(page, "#dwfrm_registrationcontactdob_dobDay", dane["dzien_ur"], typing_speed=(300, 500))
        await human_type(page, "#dwfrm_registrationcontactdob_dobMonth", dane["miesiac_ur"], typing_speed=(300, 500))
        await human_type(page, "#dwfrm_registrationcontactdob_dobYear", dane["rok_ur"], typing_speed=(300, 500))
        
        # Senior sprawdza, czy wpisał dobre daty
        await page.mouse.wheel(0, -100)
        await asyncio.sleep(random.uniform(3.0, 5.0))

        await human_type(page, "#dwfrm_registrationcontact_address2", dane["ulica"], mistake_rate=0.1, typing_speed=(300, 500))
        await asyncio.sleep(random.uniform(2.0, 3.0))

        for _ in range(random.randint(15, 20)):
            await page.mouse.wheel(0, random.randint(10, 20)) 
            await asyncio.sleep(random.uniform(0.03, 0.06))
        await asyncio.sleep(random.uniform(2.0, 4.0))

        await human_type(page, "#dwfrm_registrationcontact_city", dane["miasto"], mistake_rate=0.1, typing_speed=(300, 500))
        
        for _ in range(random.randint(15, 20)):
            await page.mouse.wheel(0, random.randint(15, 25))
            await asyncio.sleep(random.uniform(0.03, 0.06))

        # Telefon bez błędów, bardzo powoli
        print("[*] Starannie przepisuje numer telefonu...")
        await human_type(page, "#dwfrm_registrationcontact_mobileNumber", dane["telefon"], mistake_rate=0.0, typing_speed=(400, 700))
        await asyncio.sleep(random.uniform(4.0, 6.0))

        await smooth_click_element(page, 'button[type="submit"]') 
        await asyncio.sleep(random.uniform(15.0, 20.0))

    except Exception as e:
        print(f"[!] Błąd wykonania profilu: {e}")