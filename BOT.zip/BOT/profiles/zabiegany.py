# profiles/zabiegany.py
import asyncio
import random
from config import TARGET_URL
from utils import install_visual_cursor, smooth_click_element, human_type, smooth_scroll, scroll_to_top, smooth_mouse_and_click, force_navigate_to_target

async def profile_zabiegany(page, dane):
    print("\n---> [Uruchamiam] Profil: Zabiegany")
    await page.goto(TARGET_URL, wait_until="domcontentloaded")
    await asyncio.sleep(0.5) 
    
    await install_visual_cursor(page)
    
    try:
        home_url = await page.evaluate("window.location.origin")
        print(f"[*] Profil Zabiegany w biegu wpada na stronę główną: {home_url}")
        
        await page.goto(home_url, wait_until="domcontentloaded")
        await asyncio.sleep(1.0)
        await install_visual_cursor(page)
        
        print("[*] Szybki rzut oka na stronę główną...")
        await page.mouse.wheel(0, 800)
        await asyncio.sleep(0.3)
        await page.mouse.wheel(0, -800)
        await asyncio.sleep(0.5)
        
        print("[*] Błyskawicznie kieruje kursor do menu nawigacji...")
        viewport = page.viewport_size or {'width': 1920, 'height': 1080}
        try:
            pos = await page.evaluate("() => ({x: window.botMouseX || window.innerWidth/2, y: window.botMouseY || window.innerHeight/2})")
            start_x, start_y = pos['x'], pos['y']
        except Exception:
            start_x, start_y = viewport['width'] / 2, viewport['height'] / 2

        target_x = random.randint(int(viewport['width'] * 0.4), int(viewport['width'] * 0.8))
        target_y = random.randint(10, 40)
        steps = random.randint(15, 25)
        for i in range(1, steps + 1):
            t = i / steps
            ease_t = 1 - pow(1 - t, 3) 
            current_x = start_x + (target_x - start_x) * ease_t
            current_y = start_y + (target_y - start_y) * ease_t
            await page.mouse.move(current_x, current_y)
            await asyncio.sleep(random.uniform(0.002, 0.008))
        await asyncio.sleep(0.5)

        await force_navigate_to_target(page)
        await install_visual_cursor(page)
        
    except Exception as e:
        print(f"[!] Błąd w fazie błądzenia po stronie głównej: {e}")
        await force_navigate_to_target(page)
        await install_visual_cursor(page)

    try:
        print("[*] Zabiegany nie czyta. Błyskawicznie klika rejestrację...")
        await smooth_mouse_and_click(page, actions=1)
        
        await smooth_click_element(page, 'label[for="registration"]', click_count=2)
        await asyncio.sleep(0.5)
        
        print("[*] Błyskawiczne wpisywanie e-maila i hasła...")
        await human_type(page, "#dwfrm_registrationaccount_email", dane["email"], mistake_rate=0.25, typing_speed=(20, 60))
        await human_type(page, "input[id^='dwfrm_registrationaccount_password_']", dane["haslo"], mistake_rate=0.15, typing_speed=(20, 50))
        
        print("[*] Szybkie odklikiwanie zgód (byle szybciej)...")
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_pmtc"]')
        await asyncio.sleep(0.1)
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_addtoemaillist"]')
        await asyncio.sleep(0.1)
        
        await smooth_click_element(page, 'button[name="dwfrm_profile_confirm"]')
        
        print("[*] Czekam na drugi formularz (Zabiegany rusza myszką z niecierpliwości)...")
        for _ in range(3):
            await smooth_mouse_and_click(page, actions=1)
            await asyncio.sleep(0.3)
            
        await page.wait_for_selector("#dwfrm_registrationcontact_firstName", state="visible", timeout=15000)
        
        print("[*] Formularz załadowany. Zabiegany wpisuje imię z grubym błędem i agresywnie poprawia...")
        await smooth_click_element(page, "#dwfrm_registrationcontact_firstName")
        
        prefix_bledu = dane["imie"][:2] + "xxx"
        await page.type("#dwfrm_registrationcontact_firstName", prefix_bledu, delay=30)
        await asyncio.sleep(0.2) 
        
        for _ in range(3):
            await page.keyboard.press("Backspace")
            await asyncio.sleep(random.uniform(0.02, 0.05))
            
        await page.type("#dwfrm_registrationcontact_firstName", dane["imie"][2:], delay=40)
        await asyncio.sleep(0.2)
        
        await human_type(page, "#dwfrm_registrationcontact_lastName", dane["nazwisko"], mistake_rate=0.1, typing_speed=(20, 60))
        
        print("[*] Szarpany, nerwowy scroll w dół do daty urodzenia...")
        for _ in range(random.randint(4, 6)):
            await page.mouse.wheel(0, random.randint(100, 150))
            await asyncio.sleep(random.uniform(0.01, 0.03))
            
        await human_type(page, "#dwfrm_registrationcontactdob_dobDay", dane["dzien_ur"], typing_speed=(20, 50))
        await human_type(page, "#dwfrm_registrationcontactdob_dobMonth", dane["miesiac_ur"], typing_speed=(20, 50))
        await human_type(page, "#dwfrm_registrationcontactdob_dobYear", dane["rok_ur"], typing_speed=(20, 50))
        
        print("[*] Szarpany scroll i adres...")
        for _ in range(random.randint(4, 6)):
            await page.mouse.wheel(0, random.randint(100, 150))
            await asyncio.sleep(random.uniform(0.01, 0.03))
            
        await human_type(page, "#dwfrm_registrationcontact_address2", dane["ulica"], typing_speed=(20, 60))
        await human_type(page, "#dwfrm_registrationcontact_city", dane["miasto"], typing_speed=(20, 60))
        
        print("[*] Szarpany scroll i telefon...")
        for _ in range(random.randint(5, 7)):
            await page.mouse.wheel(0, random.randint(100, 150))
            await asyncio.sleep(random.uniform(0.01, 0.03))
            
        await human_type(page, "#dwfrm_registrationcontact_mobileNumber", dane["telefon"], typing_speed=(25, 55))
        
        print("[*] Podwójne kliknięcie Dalej (niecierpliwość)...")
        await smooth_click_element(page, 'button[type="submit"]', click_count=2)
        
        print("[*] Formularz wysłany. Czekam 20 sekund przed zamknięciem profilu...")
        for _ in range(4):
            await smooth_mouse_and_click(page, actions=1)
            await asyncio.sleep(5)
            
    except Exception as e:
        print(f"[!] Błąd profilu 'Zabiegany': {e}")