# profiles/nerwowy.py
import asyncio
import random
from config import TARGET_URL
from utils import install_visual_cursor, smooth_click_element, human_type, smooth_scroll, scroll_to_top, smooth_mouse_and_click, force_navigate_to_target

async def profile_nerwowy(page, dane):
    print("\n---> [Uruchamiam] Profil: Nerwowy")
    await page.goto(TARGET_URL, wait_until="domcontentloaded")
    await asyncio.sleep(1.0) 

    await install_visual_cursor(page)

    try:
        home_url = await page.evaluate("window.location.origin")
        print(f"[*] Profil Nerwowy błądzi (bardzo szybko i agresywnie)... Przechodzę na stronę główną: {home_url}")
        
        await page.goto(home_url, wait_until="domcontentloaded")
        await asyncio.sleep(1.0)
        await install_visual_cursor(page)
        
        print("[*] Szybkie szarpanie ekranem...")
        await page.mouse.wheel(0, 1500)
        await asyncio.sleep(0.3)
        await page.mouse.wheel(0, -1000)
        await smooth_mouse_and_click(page, actions=1)
        await asyncio.sleep(0.5)
        
        print("[*] Szybki najazd na pasek nawigacji...")
        viewport = page.viewport_size or {'width': 1920, 'height': 1080}
        try:
            pos = await page.evaluate("() => ({x: window.botMouseX || window.innerWidth/2, y: window.botMouseY || window.innerHeight/2})")
            start_x, start_y = pos['x'], pos['y']
        except Exception:
            start_x, start_y = viewport['width'] / 2, viewport['height'] / 2

        target_x = random.randint(int(viewport['width'] * 0.4), int(viewport['width'] * 0.8))
        target_y = random.randint(10, 40) 
        steps = random.randint(15, 25)
        for i in range(1, steps + 1):
            t = i / steps
            ease_t = 1 - pow(1 - t, 3) 
            current_x = start_x + (target_x - start_x) * ease_t
            current_y = start_y + (target_y - start_y) * ease_t
            await page.mouse.move(current_x, current_y)
            await asyncio.sleep(random.uniform(0.002, 0.005))
        await asyncio.sleep(0.3)

        await force_navigate_to_target(page)
        await install_visual_cursor(page)
        
    except Exception as e:
        print(f"[!] Błąd w fazie błądzenia po stronie głównej: {e}")
        await force_navigate_to_target(page)
        await install_visual_cursor(page)

    await page.mouse.wheel(0, 400)
    await asyncio.sleep(0.3)
    await scroll_to_top(page)
    await asyncio.sleep(0.5) 

    try:
        print("[*] Szybki najazd na rejestrację (podwójny klik)...")
        await smooth_click_element(page, 'label[for="registration"]', click_count=2)
        await asyncio.sleep(0.5) 

        await human_type(page, "#dwfrm_registrationaccount_email", dane["email"], typing_speed=(20, 60))
        await asyncio.sleep(0.2)
        await human_type(page, "input[id^='dwfrm_registrationaccount_password_']", dane["haslo"], typing_speed=(20, 60))
        
        print("[*] Szybka akceptacja zgód...")
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_pmtc"]')
        await asyncio.sleep(0.2) 
        
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_addtoemaillist"]')
        await asyncio.sleep(0.2)

        print("[*] Agresywny klik w 'Stwórz konto'...")
        await smooth_click_element(page, 'button[name="dwfrm_profile_confirm"]', click_count=2)

        print("[*] Czekam na załadowanie drugiego formularza...")
        await page.wait_for_selector("#dwfrm_registrationcontact_firstName", state="visible", timeout=15000)
        await asyncio.sleep(0.5) 

        print("[*] Błyskawicznie wypełniam Imię i Nazwisko...")
        await human_type(page, "#dwfrm_registrationcontact_firstName", dane["imie"], typing_speed=(20, 60))
        await asyncio.sleep(0.1)
        await human_type(page, "#dwfrm_registrationcontact_lastName", dane["nazwisko"], typing_speed=(20, 60))

        print("[*] Wypełniam Datę Urodzenia...")
        await page.mouse.wheel(0, 150)
        await asyncio.sleep(0.2)
        
        await human_type(page, "#dwfrm_registrationcontactdob_dobDay", dane["dzien_ur"], typing_speed=(20, 60))
        await human_type(page, "#dwfrm_registrationcontactdob_dobMonth", dane["miesiac_ur"], typing_speed=(20, 60))
        await human_type(page, "#dwfrm_registrationcontactdob_dobYear", dane["rok_ur"], typing_speed=(20, 60))

        print("[*] Wypełniam Ulicę...")
        await human_type(page, "#dwfrm_registrationcontact_address2", dane["ulica"], typing_speed=(20, 60))

        print("[*] Szarpnięcie ekranem w dół...")
        for _ in range(random.randint(3, 5)):
            await page.mouse.wheel(0, random.randint(100, 200)) 
            await asyncio.sleep(random.uniform(0.01, 0.03))
        
        print("[*] Wypełniam Miasto...")
        await human_type(page, "#dwfrm_registrationcontact_city", dane["miasto"], typing_speed=(20, 60))

        print("[*] Szarpnięcie do Telefonu...")
        for _ in range(random.randint(3, 5)):
            await page.mouse.wheel(0, random.randint(100, 200))
            await asyncio.sleep(random.uniform(0.01, 0.03))

        print("[*] Wypełniam Numer Telefonu...")
        await human_type(page, "#dwfrm_registrationcontact_mobileNumber", dane["telefon"], typing_speed=(20, 60))
        await asyncio.sleep(0.2)

        print("[*] Ostateczny, agresywny dwuklik w Dalej...")
        await smooth_click_element(page, 'button[type="submit"]', click_count=2) 

        print("[*] Formularz wysłany. Czekam 20 sekund (miota kursorem)...")
        for _ in range(10):
            await smooth_mouse_and_click(page, actions=1)
            await asyncio.sleep(2)

    except Exception as e:
        print(f"[!] Błąd wykonania profilu: {e}")