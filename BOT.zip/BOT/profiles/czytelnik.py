# profiles/czytelnik.py
import asyncio
import random
from config import TARGET_URL
from utils import install_visual_cursor, smooth_click_element, human_type, smooth_scroll, scroll_to_top, smooth_mouse_and_click, force_navigate_to_target

async def profile_czytelnik(page, dane):
    print("\n---> [Uruchamiam] Profil: Czytelnik (Metodyczny)")
    await page.goto(TARGET_URL, wait_until="domcontentloaded")
    await asyncio.sleep(2) 
    await install_visual_cursor(page)

    try:
        home_url = await page.evaluate("window.location.origin")
        print(f"[*] Czytelnik wchodzi na stronę główną: {home_url}")
        await page.goto(home_url, wait_until="domcontentloaded")
        await asyncio.sleep(random.uniform(2.5, 4.0))
        await install_visual_cursor(page)
        
        # Powolne czytanie strony głównej (krótkie scrolle, dużo pauz)
        print("[*] Czytelnik analizuje teksty na stronie głównej...")
        for _ in range(random.randint(4, 6)):
            await page.mouse.wheel(0, random.randint(150, 300))
            await smooth_mouse_and_click(page, actions=1) # Wodzenie kursorem po tekście
            await asyncio.sleep(random.uniform(2.5, 5.0)) # Czas na przeczytanie akapitu
            
        await scroll_to_top(page)
        await force_navigate_to_target(page)
        await install_visual_cursor(page)
        
    except Exception as e:
        print(f"[!] Błąd w fazie błądzenia: {e}")
        await force_navigate_to_target(page)
        await install_visual_cursor(page)

    try:
        # Faza 1
        await smooth_scroll(page, scrolls=1)
        await asyncio.sleep(random.uniform(1.5, 3.0))
        
        print("[*] Czytelnik rozpoczyna rejestrację...")
        await smooth_click_element(page, 'label[for="registration"]')
        await asyncio.sleep(random.uniform(2.0, 3.5))

        # Równe, przemyślane tempo pisania
        await human_type(page, "#dwfrm_registrationaccount_email", dane["email"], mistake_rate=0.02, typing_speed=(120, 220))
        await asyncio.sleep(random.uniform(1.0, 2.0))
        await human_type(page, "input[id^='dwfrm_registrationaccount_password_']", dane["haslo"], mistake_rate=0.0, typing_speed=(150, 250))
        
        print("[*] Czytelnik analizuje zgody prawne...")
        await smooth_mouse_and_click(page, actions=2)
        await asyncio.sleep(random.uniform(4.0, 7.0)) # Długie czytanie zgód
        
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_pmtc"]')
        await asyncio.sleep(random.uniform(1.0, 2.0)) 
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_addtoemaillist"]')
        await asyncio.sleep(random.uniform(1.5, 2.5))

        await smooth_click_element(page, 'button[name="dwfrm_profile_confirm"]')

        # Faza 2
        await page.wait_for_selector("#dwfrm_registrationcontact_firstName", state="visible", timeout=15000)
        await asyncio.sleep(random.uniform(2.0, 4.0)) 

        print("[*] Czytelnik sumiennie wypełnia dane...")
        await human_type(page, "#dwfrm_registrationcontact_firstName", dane["imie"], mistake_rate=0.02, typing_speed=(120, 220))
        await asyncio.sleep(random.uniform(0.5, 1.0))
        await human_type(page, "#dwfrm_registrationcontact_lastName", dane["nazwisko"], mistake_rate=0.02, typing_speed=(120, 220))

        await smooth_mouse_and_click(page, actions=1) 
        await human_type(page, "#dwfrm_registrationcontactdob_dobDay", dane["dzien_ur"], typing_speed=(150, 300))
        await human_type(page, "#dwfrm_registrationcontactdob_dobMonth", dane["miesiac_ur"], typing_speed=(150, 300))
        await human_type(page, "#dwfrm_registrationcontactdob_dobYear", dane["rok_ur"], typing_speed=(150, 300))
        await asyncio.sleep(random.uniform(1.0, 2.0))

        await human_type(page, "#dwfrm_registrationcontact_address2", dane["ulica"], typing_speed=(120, 220))
        await page.mouse.wheel(0, random.randint(150, 250)) 
        await asyncio.sleep(random.uniform(1.0, 2.0))

        await human_type(page, "#dwfrm_registrationcontact_city", dane["miasto"], typing_speed=(120, 220))
        await page.mouse.wheel(0, random.randint(150, 250)) 
        await asyncio.sleep(random.uniform(1.0, 2.0))

        # Telefon bez błędów
        await human_type(page, "#dwfrm_registrationcontact_mobileNumber", dane["telefon"], mistake_rate=0.0, typing_speed=(150, 300))
        await asyncio.sleep(random.uniform(2.0, 3.5))

        print("[*] Koniec. Metodyczny klik w Dalej...")
        await smooth_click_element(page, 'button[type="submit"]') 
        await asyncio.sleep(random.uniform(15.0, 20.0))

    except Exception as e:
        print(f"[!] Błąd wykonania profilu: {e}")