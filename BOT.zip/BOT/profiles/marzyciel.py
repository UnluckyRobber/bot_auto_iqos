# profiles/marzyciel.py
import asyncio
import random
from config import TARGET_URL
from utils import install_visual_cursor, smooth_click_element, human_type, smooth_scroll, scroll_to_top, smooth_mouse_and_click, force_navigate_to_target

async def odjazd_kursora_na_krawedz(page):
    """Symuluje odjechanie myszką na bok ekranu, gdy użytkownik nie patrzy na stronę."""
    viewport = page.viewport_size or {'width': 1920, 'height': 1080}
    
    # Losowa krawędź ekranu (góra, dół, lewo, prawo)
    krawedz_x = random.choice([10, viewport['width'] - 10, random.randint(100, viewport['width'])])
    krawedz_y = random.choice([10, viewport['height'] - 10, random.randint(100, viewport['height'])])
    
    await page.mouse.move(krawedz_x, krawedz_y, steps=random.randint(40, 70))
    czas_zamyślenia = random.uniform(8.0, 25.0)
    print(f"[*] Marzyciel odjeżdża myszką na krawędź i zastyga na {czas_zamyślenia:.1f} sekund...")
    await asyncio.sleep(czas_zamyślenia)

async def profile_marzyciel(page, dane):
    print("\n---> [Uruchamiam] Profil: Marzyciel (Zastyganie i martwe strefy)")
    await page.goto(TARGET_URL, wait_until="domcontentloaded")
    await asyncio.sleep(2) 
    await install_visual_cursor(page)

    try:
        await force_navigate_to_target(page)
        await install_visual_cursor(page)
    except Exception as e:
        print(f"[!] Błąd przejścia: {e}")

    try:
        await smooth_click_element(page, 'label[for="registration"]')
        await asyncio.sleep(random.uniform(2.0, 4.0)) 

        await human_type(page, "#dwfrm_registrationaccount_email", dane["email"], mistake_rate=0.08, typing_speed=(100, 300))
        
        # Pierwsze zamyślenie
        await odjazd_kursora_na_krawedz(page)
        
        await human_type(page, "input[id^='dwfrm_registrationaccount_password_']", dane["haslo"], mistake_rate=0.1, typing_speed=(150, 350))
        
        # Klika zgody bardzo leniwie
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_pmtc"]')
        await asyncio.sleep(random.uniform(3.0, 5.0)) 
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_addtoemaillist"]')
        
        await smooth_click_element(page, 'button[name="dwfrm_profile_confirm"]')
        await page.wait_for_selector("#dwfrm_registrationcontact_firstName", state="visible", timeout=20000)
        await asyncio.sleep(random.uniform(3.0, 6.0)) 

        await human_type(page, "#dwfrm_registrationcontact_firstName", dane["imie"], mistake_rate=0.1, typing_speed=(150, 400))
        await human_type(page, "#dwfrm_registrationcontact_lastName", dane["nazwisko"], mistake_rate=0.1, typing_speed=(150, 400))

        # Drugie zamyślenie
        await odjazd_kursora_na_krawedz(page)

        await human_type(page, "#dwfrm_registrationcontactdob_dobDay", dane["dzien_ur"], typing_speed=(200, 400))
        await asyncio.sleep(0.5)
        await human_type(page, "#dwfrm_registrationcontactdob_dobMonth", dane["miesiac_ur"], typing_speed=(200, 400))
        await asyncio.sleep(0.5)
        await human_type(page, "#dwfrm_registrationcontactdob_dobYear", dane["rok_ur"], typing_speed=(200, 400))

        await human_type(page, "#dwfrm_registrationcontact_address2", dane["ulica"], mistake_rate=0.1, typing_speed=(150, 300))
        await asyncio.sleep(random.uniform(2.0, 4.0))

        for _ in range(random.randint(12, 18)):
            await page.mouse.wheel(0, random.randint(20, 35))
            await asyncio.sleep(random.uniform(0.015, 0.035))
        
        await human_type(page, "#dwfrm_registrationcontact_city", dane["miasto"], mistake_rate=0.1, typing_speed=(150, 300))

        # Trzecie zamyślenie przed telefonem
        await odjazd_kursora_na_krawedz(page)

        for _ in range(random.randint(10, 20)):
            await page.mouse.wheel(0, random.randint(20, 35))
            await asyncio.sleep(random.uniform(0.015, 0.035))

        await human_type(page, "#dwfrm_registrationcontact_mobileNumber", dane["telefon"], mistake_rate=0.0, typing_speed=(150, 400))
        await asyncio.sleep(random.uniform(3.0, 5.0))

        await smooth_click_element(page, 'button[type="submit"]') 
        await asyncio.sleep(random.uniform(15.0, 20.0))

    except Exception as e:
        print(f"[!] Błąd wykonania profilu: {e}")