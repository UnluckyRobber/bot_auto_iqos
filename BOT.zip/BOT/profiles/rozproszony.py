# profiles/rozproszony.py
import asyncio
import random
from config import TARGET_URL
from utils import install_visual_cursor, smooth_click_element, human_type, smooth_scroll, scroll_to_top, smooth_mouse_and_click, force_navigate_to_target

async def profile_rozproszony(page, dane):
    print("\n---> [Uruchamiam] Profil: Rozproszony")
    await page.goto(TARGET_URL, wait_until="domcontentloaded")
    await asyncio.sleep(3)
    await install_visual_cursor(page)
    
    try:
        home_url = await page.evaluate("window.location.origin")
        print(f"[*] Profil Rozproszony na początku błądzi... Przechodzę na stronę główną: {home_url}")
        
        await page.goto(home_url, wait_until="domcontentloaded")
        await asyncio.sleep(random.uniform(2.0, 4.0))
        await install_visual_cursor(page) 
        
        await smooth_scroll(page, scrolls=random.randint(2, 4))
        await smooth_mouse_and_click(page, actions=random.randint(2, 5))
        await scroll_to_top(page)
        await asyncio.sleep(random.uniform(1.0, 3.0))
        
        await force_navigate_to_target(page)
        await install_visual_cursor(page)

        await smooth_scroll(page, scrolls=2)
        await scroll_to_top(page)
        await asyncio.sleep(2)
        
        print("[*] Najeżdżam i klikam w opcję rejestracji (Podejście 1)...")
        await smooth_click_element(page, 'label[for="registration"]')
        await asyncio.sleep(1.5)
        
        await human_type(page, "#dwfrm_registrationaccount_email", dane["email"], typing_speed=(100, 250))
        await asyncio.sleep(2)
        
        wariant_rozproszenia = random.randint(1, 2)
        
        if wariant_rozproszenia == 1:
            print("[*] Scenariusz 1: Rozproszony gubi wątek i klika w stronę główną...")
            await page.goto(home_url, wait_until="domcontentloaded")
            await asyncio.sleep(2) 
            await install_visual_cursor(page)
            
            await smooth_mouse_and_click(page, actions=2)
            await asyncio.sleep(random.uniform(4.0, 6.0))
            
            print("[*] Rozproszony przypomina sobie o rejestracji. Wraca...")
            await force_navigate_to_target(page)
            await install_visual_cursor(page)
            
            await smooth_scroll(page, scrolls=1)
            await scroll_to_top(page)
            await asyncio.sleep(2)

            print("[*] Najeżdżam i klikam w opcję rejestracji (Podejście 2)...")
            await smooth_click_element(page, 'label[for="registration"]')
            await asyncio.sleep(2.5)
            
            print("[*] Wpisuje e-mail ponownie i przechodzi do hasła...")
            await human_type(page, "#dwfrm_registrationaccount_email", dane["email"], typing_speed=(80, 200))
            await asyncio.sleep(1)
            await human_type(page, "input[id^='dwfrm_registrationaccount_password_']", dane["haslo"], typing_speed=(100, 250))
            
        else:
            print("[*] Scenariusz 2: Rozproszony bierze telefon do ręki (Zastygnięcie w formularzu)...")
            await smooth_mouse_and_click(page, actions=1)
            await asyncio.sleep(random.uniform(10.0, 18.0))
            print("[*] Rozproszony odkłada telefon. Nerwowy ruch myszką i dokończenie hasła...")
            await smooth_mouse_and_click(page, actions=3)
            await asyncio.sleep(1)
            await human_type(page, "input[id^='dwfrm_registrationaccount_password_']", dane["haslo"], typing_speed=(120, 280))

        await smooth_mouse_and_click(page, actions=1)
        
        print("[*] Akceptuje zgody...")
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_pmtc"]')
        await asyncio.sleep(1)
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_addtoemaillist"]')
        await asyncio.sleep(1)
        
        await smooth_click_element(page, 'button[name="dwfrm_profile_confirm"]')
        
        print("[*] Czekam na drugi formularz...")
        await page.wait_for_selector("#dwfrm_registrationcontact_firstName", state="visible", timeout=15000)
        await asyncio.sleep(3)
        
        await human_type(page, "#dwfrm_registrationcontact_firstName", dane["imie"], typing_speed=(100, 250))
        await asyncio.sleep(1)
        await human_type(page, "#dwfrm_registrationcontact_lastName", dane["nazwisko"], typing_speed=(100, 250))
        
        await smooth_mouse_and_click(page, actions=1)
        await human_type(page, "#dwfrm_registrationcontactdob_dobDay", dane["dzien_ur"], typing_speed=(150, 300))
        await asyncio.sleep(0.5)
        await human_type(page, "#dwfrm_registrationcontactdob_dobMonth", dane["miesiac_ur"], typing_speed=(150, 300))
        await asyncio.sleep(0.5)
        await human_type(page, "#dwfrm_registrationcontactdob_dobYear", dane["rok_ur"], typing_speed=(150, 300))
        
        await asyncio.sleep(1)
        await human_type(page, "#dwfrm_registrationcontact_address2", dane["ulica"], typing_speed=(100, 250))
        
        for _ in range(random.randint(12, 22)):
            await page.mouse.wheel(0, random.randint(10, 25))
            await asyncio.sleep(random.uniform(0.015, 0.035))
            
        await human_type(page, "#dwfrm_registrationcontact_city", dane["miasto"], typing_speed=(100, 250))
        
        for _ in range(random.randint(15, 25)):
            await page.mouse.wheel(0, random.randint(15, 30))
            await asyncio.sleep(random.uniform(0.015, 0.035))
            
        await human_type(page, "#dwfrm_registrationcontact_mobileNumber", dane["telefon"], typing_speed=(150, 350))
        
        await asyncio.sleep(2)
        await smooth_click_element(page, 'button[type="submit"]')
        
        print("[*] Formularz wysłany. Czekam 20 sekund przed zamknięciem profilu...")
        for _ in range(4):
            await smooth_mouse_and_click(page, actions=1)
            await asyncio.sleep(5)
            
    except Exception as e:
        print(f"[!] Błąd wykonania profilu: {e}")