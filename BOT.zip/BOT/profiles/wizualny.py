# profiles/wizualny.py
import asyncio
import random
from config import TARGET_URL
from utils import install_visual_cursor, smooth_click_element, human_type, smooth_scroll, scroll_to_top, smooth_mouse_and_click, force_navigate_to_target

async def profile_wizualny(page, dane):
    print("\n---> [Uruchamiam] Profil: Wizualny")
    await page.goto(TARGET_URL, wait_until="domcontentloaded")
    await asyncio.sleep(2)
    
    await install_visual_cursor(page)
    
    try:
        home_url = await page.evaluate("window.location.origin")
        print(f"[*] Profil Wizualny zaczyna od skanowania strony głównej: {home_url}")
        
        await page.goto(home_url, wait_until="domcontentloaded")
        await asyncio.sleep(random.uniform(3.0, 5.0))
        await install_visual_cursor(page)
        
        print("[*] Wizualny skanuje układ strony. Zjeżdża płynnie w dół...")
        for _ in range(3):
            await smooth_scroll(page, scrolls=1)
            await smooth_mouse_and_click(page, actions=random.randint(1, 3))
            await asyncio.sleep(random.uniform(1.5, 3.0))
            
        print("[*] Zrozumiał układ strony. Wraca na górę...")
        await scroll_to_top(page)
        await asyncio.sleep(2) 
        
        print("[*] Kieruję kursor w stronę paska nawigacji/adresu...")
        viewport = page.viewport_size or {'width': 1920, 'height': 1080}
        try:
            pos = await page.evaluate("() => ({x: window.botMouseX || window.innerWidth/2, y: window.botMouseY || window.innerHeight/2})")
            start_x, start_y = pos['x'], pos['y']
        except Exception:
            start_x, start_y = viewport['width'] / 2, viewport['height'] / 2

        target_x = random.randint(int(viewport['width'] * 0.4), int(viewport['width'] * 0.8))
        target_y = random.randint(10, 40)
        steps = random.randint(40, 65)
        for i in range(1, steps + 1):
            t = i / steps
            ease_t = 1 - pow(1 - t, 3) 
            current_x = start_x + (target_x - start_x) * ease_t
            current_y = start_y + (target_y - start_y) * ease_t
            await page.mouse.move(current_x, current_y)
            await asyncio.sleep(random.uniform(0.005, 0.015))
        await asyncio.sleep(random.uniform(0.5, 1.5))

        await force_navigate_to_target(page)
        await install_visual_cursor(page)
        
    except Exception as e:
        print(f"[!] Błąd w fazie błądzenia po stronie głównej: {e}")
        await force_navigate_to_target(page)
        await install_visual_cursor(page)

    try:
        print("[*] Namierza wzrokiem opcję rejestracji...")
        await smooth_click_element(page, 'label[for="registration"]')
        await asyncio.sleep(2.5)
        
        print("[*] Wpisuje e-mail i wizualnie go sprawdza...")
        await human_type(page, "#dwfrm_registrationaccount_email", dane["email"], typing_speed=(120, 250))
        await smooth_mouse_and_click(page, actions=1)
        await asyncio.sleep(3) 
        
        await human_type(page, "input[id^='dwfrm_registrationaccount_password_']", dane["haslo"], typing_speed=(120, 250))
        await asyncio.sleep(1)
        
        print("[*] Wizualnie analizuje zgody...")
        await smooth_mouse_and_click(page, actions=2) 
        await asyncio.sleep(2)
        
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_pmtc"]')
        await asyncio.sleep(1)
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_addtoemaillist"]')
        await asyncio.sleep(1)
        
        await smooth_click_element(page, 'button[name="dwfrm_profile_confirm"]')
        
        print("[*] Czekam na załadowanie drugiego formularza...")
        await page.wait_for_selector("#dwfrm_registrationcontact_firstName", state="visible", timeout=15000)
        await asyncio.sleep(3)
        
        print("[*] Wizualny musi najpierw zobaczyć CAŁY formularz, zanim cokolwiek wpisze...")
        for _ in range(random.randint(4, 6)):
            await page.mouse.wheel(0, random.randint(150, 200))
            await asyncio.sleep(random.uniform(0.1, 0.3))
        await asyncio.sleep(2)
        
        print("[*] Wie już, ile jest pracy. Wraca do imienia i nazwiska...")
        await scroll_to_top(page)
        await asyncio.sleep(1.5)
        
        await human_type(page, "#dwfrm_registrationcontact_firstName", dane["imie"], typing_speed=(120, 250))
        await asyncio.sleep(1)
        await human_type(page, "#dwfrm_registrationcontact_lastName", dane["nazwisko"], typing_speed=(120, 250))
        
        print("[*] Centrowanie formularza na dacie urodzenia i adresie...")
        for _ in range(random.randint(12, 18)):
            await page.mouse.wheel(0, random.randint(20, 35))
            await asyncio.sleep(random.uniform(0.015, 0.035))
        
        await human_type(page, "#dwfrm_registrationcontactdob_dobDay", dane["dzien_ur"], typing_speed=(120, 250))
        await human_type(page, "#dwfrm_registrationcontactdob_dobMonth", dane["miesiac_ur"], typing_speed=(120, 250))
        await human_type(page, "#dwfrm_registrationcontactdob_dobYear", dane["rok_ur"], typing_speed=(120, 250))
        await asyncio.sleep(1)
        
        await human_type(page, "#dwfrm_registrationcontact_address2", dane["ulica"], typing_speed=(120, 250))
        await human_type(page, "#dwfrm_registrationcontact_city", dane["miasto"], typing_speed=(120, 250))
        
        print("[*] Lekki zjazd do telefonu i wizualne namierzenie pola...")
        for _ in range(random.randint(12, 18)):
            await page.mouse.wheel(0, random.randint(20, 35))
            await asyncio.sleep(random.uniform(0.015, 0.035))
        
        await human_type(page, "#dwfrm_registrationcontact_mobileNumber", dane["telefon"], typing_speed=(150, 300))
        
        print("[*] Kontrola wzrokowa telefonu przed kliknięciem...")
        await smooth_mouse_and_click(page, actions=1)
        await asyncio.sleep(2)
        
        print("[*] Wszystko wygląda dobrze. Klika Dalej...")
        await smooth_click_element(page, 'button[type="submit"]')
        
        print("[*] Formularz wysłany. Wizualny kręci kursorem w trakcie 20-sekundowego oczekiwania...")
        for _ in range(4):
            await smooth_mouse_and_click(page, actions=random.randint(1, 3)) 
            await asyncio.sleep(5)
            
    except Exception as e:
        print(f"[!] Błąd profilu 'Wizualny': {e}")