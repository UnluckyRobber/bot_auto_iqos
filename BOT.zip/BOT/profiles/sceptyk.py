# profiles/sceptyk.py
import asyncio
import random
from config import TARGET_URL
from utils import install_visual_cursor, smooth_click_element, human_type, smooth_scroll, scroll_to_top, smooth_mouse_and_click, force_navigate_to_target, ludzka_pauza

async def profile_sceptyk(page, dane):
    print("\n---> [Uruchamiam] Profil: Sceptyk")
    
    # ========================================================
    # TYLKO TO MA BYĆ NA GÓRZE - ŻADNYCH GOTO I SLEEP!
    # force_navigate_to_target robi wszystko: wchodzi na stronę i odklikuje pop-upy
    # ========================================================
    await force_navigate_to_target(page)

    try:
        home_url = await page.evaluate("window.location.origin")
        print(f"[*] Profil Sceptyk bada wiarygodność... Przechodzę na stronę główną: {home_url}")
        
        await page.goto(home_url, wait_until="domcontentloaded")
        await ludzka_pauza(4.0)
        await install_visual_cursor(page)
        
        print("[*] Błądzenie Faza 1: Sceptyk czyta nagłówki...")
        await smooth_mouse_and_click(page, actions=random.randint(2, 4))
        await ludzka_pauza(3.0)

        print("[*] Błądzenie Faza 2: Zjeżdżanie w głąb witryny, szukanie haczyków...")
        await smooth_scroll(page, scrolls=random.randint(4, 7))
        await smooth_mouse_and_click(page, actions=random.randint(3, 6))
        await ludzka_pauza(4.0)

        print("[*] Błądzenie Faza 3: Wahnięcie i doczytywanie tekstu...")
        await page.mouse.wheel(0, random.randint(-700, -300))
        await ludzka_pauza(1.8)
        await smooth_scroll(page, scrolls=random.randint(2, 4))
        await smooth_mouse_and_click(page, actions=random.randint(2, 4))
        await ludzka_pauza(3.5)

        await scroll_to_top(page)
        await ludzka_pauza(3.0)
        
        print("[*] Kieruję kursor w stronę paska nawigacji/adresu...")
        viewport = page.viewport_size or {'width': 1920, 'height': 1080}
        try:
            pos = await page.evaluate("() => ({x: window.botMouseX || window.innerWidth/2, y: window.botMouseY || window.innerHeight/2})")
            start_x, start_y = pos['x'], pos['y']
        except Exception:
            start_x, start_y = viewport['width'] / 2, viewport['height'] / 2

        target_x = random.randint(int(viewport['width'] * 0.4), int(viewport['width'] * 0.8))
        target_y = random.randint(10, 40)
        steps = random.randint(40, 65)
        
        # Mikro-pauzy sprzętowe w pętli zostawiamy jako standardowe asyncio.sleep
        for i in range(1, steps + 1):
            t = i / steps
            ease_t = 1 - pow(1 - t, 3) 
            current_x = start_x + (target_x - start_x) * ease_t
            current_y = start_y + (target_y - start_y) * ease_t
            await page.mouse.move(current_x, current_y)
            await asyncio.sleep(random.uniform(0.005, 0.015))
            
        await ludzka_pauza(1.0)
        
        # Sceptyk wraca na podstronę rejestracji, żelazna nawigacja znowu upewni się, czy nie trzeba czegoś kliknąć
        await force_navigate_to_target(page)

    except Exception as e:
        print(f"[!] Błąd w fazie błądzenia po stronie głównej: {e}")
        await force_navigate_to_target(page)

    try:
        print("[*] Sceptyk rozgląda się po stronie rejestracji...")
        await smooth_scroll(page, scrolls=2)
        await scroll_to_top(page)
        await smooth_mouse_and_click(page, actions=1)
        await ludzka_pauza(2.0)
        
        print("[*] Otwieram formularz rejestracji...")
        await smooth_click_element(page, 'label[for="registration"]')
        await ludzka_pauza(2.0)
        
        print("[*] Sceptyk bada sekcję z regulaminami...")
        reg_selector = 'a[href*="informacje_prawne"][target="_blank"]'
        reg_locator = page.locator(reg_selector).first
        await reg_locator.scroll_into_view_if_needed()
        await ludzka_pauza(1.0)
        await page.mouse.wheel(0, -150)
        await ludzka_pauza(2.0)

        wariant_sceptyka = random.randint(1, 2)
        
        if wariant_sceptyka == 1:
            print("[*] Scenariusz 1: Sceptyk znajduje link do regulaminu i w niego klika...")
            async with page.context.expect_page() as new_page_info:
                await smooth_click_element(page, reg_selector)
                
            reg_page = await new_page_info.value
            await reg_page.wait_for_load_state("domcontentloaded")
            await ludzka_pauza(1.0)
            
            await reg_page.bring_to_front()
            await install_visual_cursor(reg_page)
            
            print("[*] Sceptyk czyta regulamin (głębokie, powolne przewijanie)...")
            await smooth_scroll(reg_page, scrolls=random.randint(5, 8)) 
            
            print("[*] Sceptyk wodzi kursorem po tekście...")
            await smooth_mouse_and_click(reg_page, actions=random.randint(3, 5))
            await ludzka_pauza(5.5)
            
            print("[*] Regulamin zaakceptowany mentalnie. Zamykam kartę.")
            await reg_page.close()
            await page.bring_to_front()
            await ludzka_pauza(2.0)
        else:
            print("[*] Scenariusz 2: Sceptyk waha się, wodzi kursorem po tekście, ale ostatecznie odpuszcza otwieranie PDF...")
            await smooth_mouse_and_click(page, actions=3)
            await ludzka_pauza(6.5)
            await page.mouse.wheel(0, 100)
            await ludzka_pauza(2.0)

        print("[*] Wracam na górę formularza...")
        await scroll_to_top(page)
        await ludzka_pauza(1.5)

        print("[*] Bardzo ostrożne wpisywanie danych logowania...")
        if wariant_sceptyka == 1:
            await human_type(page, "#dwfrm_registrationaccount_email", dane["email"], typing_speed=(200, 450))
            await ludzka_pauza(2.0)
            await human_type(page, "input[id^='dwfrm_registrationaccount_password_']", dane["haslo"], typing_speed=(250, 500))
        else:
            await human_type(page, "#dwfrm_registrationaccount_email", dane["email"], typing_speed=(150, 350))
            await ludzka_pauza(1.0)
            await human_type(page, "input[id^='dwfrm_registrationaccount_password_']", dane["haslo"], typing_speed=(180, 400))
        
        print("[*] Sceptyk przewija w dół do sekcji zgód...")
        zgody_locator = page.locator('label[for="dwfrm_registrationaccount_pmtc"]').first
        await zgody_locator.scroll_into_view_if_needed()
        await ludzka_pauza(1.0)
        
        await smooth_mouse_and_click(page, actions=1)
        
        print("[*] Zawahanie przed zaznaczeniem zgód...")
        await ludzka_pauza(3.0) 
        
        print("[*] Akceptuję regulamin...")
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_pmtc"]')
        await ludzka_pauza(1.8) 
        
        print("[*] Akceptuję zgody marketingowe (niechętnie)...")
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_addtoemaillist"]')
        await ludzka_pauza(1.8)

        print("[*] Klikam w 'Stwórz konto'...")
        btn_locator = page.locator('button[name="dwfrm_profile_confirm"]').first
        await btn_locator.scroll_into_view_if_needed()
        await ludzka_pauza(0.5)
        await smooth_click_element(page, 'button[name="dwfrm_profile_confirm"]')

        print("[*] Czekam na załadowanie drugiego formularza...")
        await page.wait_for_selector("#dwfrm_registrationcontact_firstName", state="visible", timeout=15000)
        await ludzka_pauza(3.0) 
        
        print("[*] Przeglądam nowy formularz...")
        await smooth_scroll(page, scrolls=1)
        await scroll_to_top(page)
        await ludzka_pauza(2.0)

        print("[*] Sceptyk z rezygnacją wypełnia Imię i Nazwisko...")
        await human_type(page, "#dwfrm_registrationcontact_firstName", dane["imie"], typing_speed=(200, 400))
        await ludzka_pauza(1.0)
        await human_type(page, "#dwfrm_registrationcontact_lastName", dane["nazwisko"], typing_speed=(200, 400))
        
        print("[*] Wypełnia datę urodzenia...")
        await smooth_mouse_and_click(page, actions=1)
        await ludzka_pauza(1.5)
        
        await human_type(page, "#dwfrm_registrationcontactdob_dobDay", dane["dzien_ur"], typing_speed=(200, 400))
        await ludzka_pauza(0.5)
        await human_type(page, "#dwfrm_registrationcontactdob_dobMonth", dane["miesiac_ur"], typing_speed=(200, 400))
        await ludzka_pauza(0.5)
        await human_type(page, "#dwfrm_registrationcontactdob_dobYear", dane["rok_ur"], typing_speed=(200, 400))
        await ludzka_pauza(1.5)

        print("[*] Wypełnia adres...")
        await human_type(page, "#dwfrm_registrationcontact_address2", dane["ulica"], typing_speed=(200, 400))
        await ludzka_pauza(1.5)
        
        print("[*] Podciągam ekran w dół, żeby zobaczyć pole Miasto...")
        for _ in range(random.randint(12, 22)):
            await page.mouse.wheel(0, random.randint(10, 25))
            await asyncio.sleep(random.uniform(0.015, 0.035))
        await ludzka_pauza(1.5)
            
        print("[*] Wypełniam Miasto...")
        await human_type(page, "#dwfrm_registrationcontact_city", dane["miasto"], typing_speed=(200, 400))
        await ludzka_pauza(1.5)

        print("[*] Podciągam ekran w dół, żeby zobaczyć pole Telefonu...")
        for _ in range(random.randint(15, 25)):
            await page.mouse.wheel(0, random.randint(15, 30))
            await asyncio.sleep(random.uniform(0.015, 0.035))
        await ludzka_pauza(2.2)
            
        print("[*] Bardzo długie zawahanie przed podaniem numeru telefonu...")
        await smooth_mouse_and_click(page, actions=2)
        await ludzka_pauza(4.0) 
        
        await human_type(page, "#dwfrm_registrationcontact_mobileNumber", dane["telefon"], typing_speed=(250, 500))
        await ludzka_pauza(2.2)
        
        print("[*] Koniec. Szukam przycisku Dalej i w niego klikam...")
        await smooth_click_element(page, 'button[type="submit"]')
        
        print("[*] Formularz wysłany. Czekam 20 sekund przed zamknięciem profilu...")
        for _ in range(4):
            await smooth_mouse_and_click(page, actions=1)
            await ludzka_pauza(5.0)
            
    except Exception as e:
        print(f"[!] Błąd profilu 'Sceptyk': {e}")