# profiles/multitasker.py
import asyncio
import random
from config import TARGET_URL
from utils import install_visual_cursor, smooth_click_element, human_type, smooth_scroll, scroll_to_top, smooth_mouse_and_click, force_navigate_to_target

async def nagle_odwrocenie_uwagi():
    """Symuluje patrzenie w telefon lub zmianę karty w przeglądarce."""
    if random.random() < 0.4: # 40% szans na odwrócenie uwagi
        czas_przerwy = random.uniform(12.0, 25.0)
        print(f"[*] Multitasker sprawda powiadomienia na telefonie... (Pauza: {czas_przerwy:.1f}s)")
        await asyncio.sleep(czas_przerwy)

async def profile_multitasker(page, dane):
    print("\n---> [Uruchamiam] Profil: Multitasker (Odwracający uwagę)")
    await page.goto(TARGET_URL, wait_until="domcontentloaded")
    await asyncio.sleep(2) 
    await install_visual_cursor(page)

    try:
        await force_navigate_to_target(page)
        await install_visual_cursor(page)
    except Exception as e:
        print(f"[!] Błąd w fazie błądzenia: {e}")

    try:
        await smooth_click_element(page, 'label[for="registration"]')
        await asyncio.sleep(random.uniform(1.0, 2.0)) 

        await human_type(page, "#dwfrm_registrationaccount_email", dane["email"], mistake_rate=0.05, typing_speed=(50, 150))
        await nagle_odwrocenie_uwagi() # Może się zatrzymać
        
        await human_type(page, "input[id^='dwfrm_registrationaccount_password_']", dane["haslo"], mistake_rate=0.05, typing_speed=(50, 150))
        
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_pmtc"]')
        await asyncio.sleep(random.uniform(0.5, 1.5)) 
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_addtoemaillist"]')
        
        await nagle_odwrocenie_uwagi()

        await smooth_click_element(page, 'button[name="dwfrm_profile_confirm"]')

        await page.wait_for_selector("#dwfrm_registrationcontact_firstName", state="visible", timeout=15000)
        await asyncio.sleep(random.uniform(1.0, 2.0)) 

        await human_type(page, "#dwfrm_registrationcontact_firstName", dane["imie"], typing_speed=(50, 150))
        await nagle_odwrocenie_uwagi()
        
        await human_type(page, "#dwfrm_registrationcontact_lastName", dane["nazwisko"], typing_speed=(50, 150))

        await human_type(page, "#dwfrm_registrationcontactdob_dobDay", dane["dzien_ur"], typing_speed=(80, 200))
        await human_type(page, "#dwfrm_registrationcontactdob_dobMonth", dane["miesiac_ur"], typing_speed=(80, 200))
        await human_type(page, "#dwfrm_registrationcontactdob_dobYear", dane["rok_ur"], typing_speed=(80, 200))
        
        await nagle_odwrocenie_uwagi()

        await human_type(page, "#dwfrm_registrationcontact_address2", dane["ulica"], typing_speed=(50, 150))
        
        for _ in range(random.randint(15, 25)):
            await page.mouse.wheel(0, random.randint(10, 30)) 
            await asyncio.sleep(random.uniform(0.01, 0.02))

        await human_type(page, "#dwfrm_registrationcontact_city", dane["miasto"], typing_speed=(50, 150))
        
        await nagle_odwrocenie_uwagi()

        for _ in range(random.randint(15, 25)):
            await page.mouse.wheel(0, random.randint(15, 30))
            await asyncio.sleep(random.uniform(0.01, 0.02))

        # Telefon bez błędów
        await human_type(page, "#dwfrm_registrationcontact_mobileNumber", dane["telefon"], mistake_rate=0.0, typing_speed=(80, 250))
        
        await smooth_click_element(page, 'button[type="submit"]') 
        await asyncio.sleep(random.uniform(15.0, 20.0))

    except Exception as e:
        print(f"[!] Błąd wykonania profilu: {e}")