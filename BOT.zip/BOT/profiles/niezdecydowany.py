# profiles/niezdecydowany.py
import asyncio
import random
from config import TARGET_URL
from utils import install_visual_cursor, smooth_click_element, human_type, smooth_scroll, scroll_to_top, smooth_mouse_and_click, force_navigate_to_target

async def wpisz_skasuj_wpisz(page, selector, text):
    """Wpisuje poprawny tekst, zamyśla się, usuwa go w całości i wpisuje na nowo."""
    print(f"[*] Niezdecydowany waha się w polu {selector}...")
    # Pierwsze wpisanie
    await human_type(page, selector, text, typing_speed=(100, 250))
    await asyncio.sleep(random.uniform(2.0, 4.0))
    
    # Kasowanie całego pola
    for _ in range(len(text)):
        await page.keyboard.press("Backspace")
        await asyncio.sleep(random.uniform(0.05, 0.15))
        
    await asyncio.sleep(random.uniform(1.0, 2.5))
    
    # Ponowne wpisanie ostateczne
    await human_type(page, selector, text, typing_speed=(100, 250))

async def profile_niezdecydowany(page, dane):
    print("\n---> [Uruchamiam] Profil: Niezdecydowany (Kasuje i poprawia dobre dane)")
    await page.goto(TARGET_URL, wait_until="domcontentloaded")
    await asyncio.sleep(2) 
    await install_visual_cursor(page)

    try:
        await force_navigate_to_target(page)
        await install_visual_cursor(page)
    except Exception as e:
        print(f"[!] Błąd przejścia: {e}")

    try:
        await smooth_click_element(page, 'label[for="registration"]')
        await asyncio.sleep(2.0) 

        await wpisz_skasuj_wpisz(page, "#dwfrm_registrationaccount_email", dane["email"])
        await asyncio.sleep(1.0)
        await human_type(page, "input[id^='dwfrm_registrationaccount_password_']", dane["haslo"], mistake_rate=0.05, typing_speed=(120, 280))
        
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_pmtc"]')
        await asyncio.sleep(1.5) 
        
        # Zaznacza zgodę, zamyśla się i... odznacza ją, po czym znów zaznacza
        print("[*] Klika zgody, cofa decyzję i znowu zaznacza...")
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_addtoemaillist"]')
        await asyncio.sleep(2.0)
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_addtoemaillist"]')
        await asyncio.sleep(3.0)
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_addtoemaillist"]')

        await smooth_click_element(page, 'button[name="dwfrm_profile_confirm"]')

        await page.wait_for_selector("#dwfrm_registrationcontact_firstName", state="visible", timeout=15000)
        await asyncio.sleep(3.0) 

        await human_type(page, "#dwfrm_registrationcontact_firstName", dane["imie"], typing_speed=(150, 300))
        await asyncio.sleep(1.0)
        
        await wpisz_skasuj_wpisz(page, "#dwfrm_registrationcontact_lastName", dane["nazwisko"])

        await human_type(page, "#dwfrm_registrationcontactdob_dobDay", dane["dzien_ur"], typing_speed=(150, 300))
        await human_type(page, "#dwfrm_registrationcontactdob_dobMonth", dane["miesiac_ur"], typing_speed=(150, 300))
        await human_type(page, "#dwfrm_registrationcontactdob_dobYear", dane["rok_ur"], typing_speed=(150, 300))
        await asyncio.sleep(1.0)

        await human_type(page, "#dwfrm_registrationcontact_address2", dane["ulica"], typing_speed=(150, 300))
        
        for _ in range(random.randint(12, 18)):
            await page.mouse.wheel(0, random.randint(20, 35))
            await asyncio.sleep(random.uniform(0.015, 0.035))
            
        await human_type(page, "#dwfrm_registrationcontact_city", dane["miasto"], typing_speed=(150, 300))

        for _ in range(random.randint(12, 18)):
            await page.mouse.wheel(0, random.randint(20, 35))
            await asyncio.sleep(random.uniform(0.015, 0.035))

        # Zgodnie z zasadą - telefonu nie ruszamy mechaniką usuwania, wpisuje raz a dobrze.
        await human_type(page, "#dwfrm_registrationcontact_mobileNumber", dane["telefon"], mistake_rate=0.0, typing_speed=(150, 300))
        await asyncio.sleep(2.0)
        
        # Błądzenie wokół ostatecznego przycisku
        print("[*] Błądzi kursorem po przycisku...")
        await smooth_mouse_and_click(page, actions=3)
        await asyncio.sleep(2.0)

        await smooth_click_element(page, 'button[type="submit"]') 
        await asyncio.sleep(random.uniform(15.0, 20.0))

    except Exception as e:
        print(f"[!] Błąd wykonania profilu: {e}")