# profiles/tabulator.py
import asyncio
import random
from config import TARGET_URL
from utils import install_visual_cursor, smooth_click_element, human_type, smooth_scroll, scroll_to_top, smooth_mouse_and_click, force_navigate_to_target

async def type_without_mouse(page, text, mistake_rate=0.0, typing_speed=(80, 200)):
    """Pisze tekst tam, gdzie aktualnie znajduje się focus klawiatury (bez klikania myszką!)."""
    for char in text:
        if random.random() < mistake_rate:
            wrong_char = random.choice(['x', 'q', 'w', 'a', 's'])
            await page.keyboard.type(wrong_char, delay=random.randint(*typing_speed))
            await asyncio.sleep(random.uniform(0.1, 0.3))
            await page.keyboard.press("Backspace")
            await asyncio.sleep(random.uniform(0.1, 0.2))
        await page.keyboard.type(char, delay=random.randint(*typing_speed))

async def profile_tabulator(page, dane):
    print("\n---> [Uruchamiam] Profil: Tabulator (Nawigacja klawiszowa)")
    await page.goto(TARGET_URL, wait_until="domcontentloaded")
    await asyncio.sleep(2) 
    await install_visual_cursor(page)

    try:
        await force_navigate_to_target(page)
        await install_visual_cursor(page)
    except Exception as e:
        print(f"[!] Błąd przejścia: {e}")

    try:
        await smooth_click_element(page, 'label[for="registration"]')
        await asyncio.sleep(2.0) 

        # Klikamy tylko w pierwszy input, by nadać mu "focus"
        await smooth_click_element(page, "#dwfrm_registrationaccount_email")
        await type_without_mouse(page, dane["email"], mistake_rate=0.1)
        
        print("[*] Tabulator przeskakuje klawiszem TAB do hasła...")
        await page.keyboard.press("Tab")
        await asyncio.sleep(random.uniform(0.5, 1.5))
        await type_without_mouse(page, dane["haslo"], mistake_rate=0.1)

        # Myszka wraca do łask tylko po to, by kliknąć zgody
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_pmtc"]')
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_addtoemaillist"]')
        await smooth_click_element(page, 'button[name="dwfrm_profile_confirm"]')

        await page.wait_for_selector("#dwfrm_registrationcontact_firstName", state="visible", timeout=15000)
        await asyncio.sleep(random.uniform(2.0, 3.0)) 

        # Klik w Imię i jedziemy klawiaturą
        await smooth_click_element(page, "#dwfrm_registrationcontact_firstName")
        await type_without_mouse(page, dane["imie"], mistake_rate=0.1)
        
        print("[*] Tabulator przeskakuje do Nazwiska...")
        await page.keyboard.press("Tab")
        await asyncio.sleep(random.uniform(0.3, 0.8))
        await type_without_mouse(page, dane["nazwisko"], mistake_rate=0.1)

        print("[*] Przeskakuje do Daty...")
        await page.keyboard.press("Tab") # Przeskok do Dnia
        await asyncio.sleep(random.uniform(0.3, 0.8))
        await type_without_mouse(page, dane["dzien_ur"])
        
        await page.keyboard.press("Tab") # Przeskok do Miesiąca
        await asyncio.sleep(random.uniform(0.3, 0.8))
        await type_without_mouse(page, dane["miesiac_ur"])

        await page.keyboard.press("Tab") # Przeskok do Roku
        await asyncio.sleep(random.uniform(0.3, 0.8))
        await type_without_mouse(page, dane["rok_ur"])

        # Powrót do myszki na adres, bo strony często łamią focus na listach rozwijanych
        await human_type(page, "#dwfrm_registrationcontact_address2", dane["ulica"], mistake_rate=0.1)
        
        for _ in range(random.randint(12, 18)):
            await page.mouse.wheel(0, random.randint(20, 35))
            await asyncio.sleep(random.uniform(0.015, 0.035))
        
        await human_type(page, "#dwfrm_registrationcontact_city", dane["miasto"], mistake_rate=0.1)

        for _ in range(random.randint(12, 18)):
            await page.mouse.wheel(0, random.randint(20, 35))
            await asyncio.sleep(random.uniform(0.015, 0.035))

        await human_type(page, "#dwfrm_registrationcontact_mobileNumber", dane["telefon"], mistake_rate=0.0)
        
        # Ostatni tab na przycisk i enter!
        print("[*] Używa TAB i ENTER, by wysłać formularz...")
        await page.keyboard.press("Tab")
        await asyncio.sleep(random.uniform(0.5, 1.0))
        await page.keyboard.press("Enter")

        await asyncio.sleep(random.uniform(15.0, 20.0))

    except Exception as e:
        print(f"[!] Błąd wykonania profilu: {e}")