# profiles/mala_klawiatura.py
import asyncio
import random
from config import TARGET_URL
from utils import install_visual_cursor, smooth_click_element, human_type, smooth_scroll, scroll_to_top, smooth_mouse_and_click, force_navigate_to_target

async def profile_mala_klawiatura(page, dane):
    print("\n---> [Uruchamiam] Profil: Mała Klawiatura")
    await page.goto(TARGET_URL, wait_until="domcontentloaded")
    await asyncio.sleep(3) 

    await install_visual_cursor(page)

    try:
        home_url = await page.evaluate("window.location.origin")
        print(f"[*] Profil Mała Klawiatura błądzi... Przechodzę na stronę główną: {home_url}")
        
        await page.goto(home_url, wait_until="domcontentloaded")
        await asyncio.sleep(random.uniform(3.0, 5.0))
        await install_visual_cursor(page)
        
        print("[*] Przeglądanie witryny (powolne ruchy)...")
        await smooth_mouse_and_click(page, actions=random.randint(2, 4))
        await smooth_scroll(page, scrolls=random.randint(3, 5))
        await asyncio.sleep(random.uniform(2.0, 4.0))
        await smooth_mouse_and_click(page, actions=random.randint(2, 3))
        
        await scroll_to_top(page)
        await asyncio.sleep(random.uniform(2.0, 4.0))
        
        print("[*] Kieruję kursor w stronę paska nawigacji...")
        viewport = page.viewport_size or {'width': 1920, 'height': 1080}
        
        try:
            pos = await page.evaluate("() => ({x: window.botMouseX || window.innerWidth/2, y: window.botMouseY || window.innerHeight/2})")
            start_x, start_y = pos['x'], pos['y']
        except Exception:
            start_x, start_y = viewport['width'] / 2, viewport['height'] / 2

        target_x = random.randint(int(viewport['width'] * 0.4), int(viewport['width'] * 0.8))
        target_y = random.randint(10, 40)
        
        steps = random.randint(40, 65)
        for i in range(1, steps + 1):
            t = i / steps
            ease_t = 1 - pow(1 - t, 3)
            current_x = start_x + (target_x - start_x) * ease_t
            current_y = start_y + (target_y - start_y) * ease_t
            await page.mouse.move(current_x, current_y)
            await asyncio.sleep(random.uniform(0.005, 0.015))

        await asyncio.sleep(random.uniform(0.5, 1.5))
        await force_navigate_to_target(page)
        await install_visual_cursor(page)
        
    except Exception as e:
        print(f"[!] Błąd w fazie błądzenia po stronie głównej: {e}")
        await force_navigate_to_target(page)
        await install_visual_cursor(page)

    try:
        await smooth_scroll(page, scrolls=random.randint(2, 4))
        await scroll_to_top(page)
        await asyncio.sleep(2) 

        print("[*] Najeżdżam i klikam w opcję rejestracji...")
        await smooth_click_element(page, 'label[for="registration"]')
        await asyncio.sleep(2) 

        print("[*] Pisanie z błędami (duże palce)...")
        await human_type(page, "#dwfrm_registrationaccount_email", dane["email"], mistake_rate=0.15, typing_speed=(150, 450))
        await asyncio.sleep(3)
        await human_type(page, "input[id^='dwfrm_registrationaccount_password_']", dane["haslo"], mistake_rate=0.20, typing_speed=(200, 500))
        
        await smooth_mouse_and_click(page, actions=1)
        await asyncio.sleep(2)
        
        print("[*] Akceptuję zgody...")
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_pmtc"]', position={"x": 10, "y": 10})
        await asyncio.sleep(random.uniform(1.0, 2.0)) 
        await smooth_click_element(page, 'label[for="dwfrm_registrationaccount_addtoemaillist"]', position={"x": 10, "y": 10})
        await asyncio.sleep(random.uniform(1.0, 2.0))

        print("[*] Klikam w 'Stwórz konto'...")
        await smooth_click_element(page, 'button[name="dwfrm_profile_confirm"]')

        print("[*] Czekam na załadowanie drugiego formularza...")
        await page.wait_for_selector("#dwfrm_registrationcontact_firstName", state="visible", timeout=15000)
        await asyncio.sleep(random.uniform(2.0, 4.0))

        print("[*] Wypełniam Imię i Nazwisko (dużo pomyłek)...")
        await human_type(page, "#dwfrm_registrationcontact_firstName", dane["imie"], mistake_rate=0.15, typing_speed=(200, 450))
        await asyncio.sleep(random.uniform(1.0, 2.5))
        await human_type(page, "#dwfrm_registrationcontact_lastName", dane["nazwisko"], mistake_rate=0.15, typing_speed=(200, 450))

        print("[*] Szukam i wypełniam Datę Urodzenia...")
        await smooth_mouse_and_click(page, actions=1) 
        await asyncio.sleep(random.uniform(1.0, 2.0))
        
        await human_type(page, "#dwfrm_registrationcontactdob_dobDay", dane["dzien_ur"], mistake_rate=0.1, typing_speed=(200, 450))
        await asyncio.sleep(random.uniform(0.5, 1.5))
        await human_type(page, "#dwfrm_registrationcontactdob_dobMonth", dane["miesiac_ur"], mistake_rate=0.1, typing_speed=(200, 450))
        await asyncio.sleep(random.uniform(0.5, 1.5))
        await human_type(page, "#dwfrm_registrationcontactdob_dobYear", dane["rok_ur"], mistake_rate=0.1, typing_speed=(200, 450))
        await asyncio.sleep(random.uniform(1.0, 2.0))

        print("[*] Wypełniam Ulicę...")
        await human_type(page, "#dwfrm_registrationcontact_address2", dane["ulica"], mistake_rate=0.15, typing_speed=(200, 450))
        await asyncio.sleep(random.uniform(1.0, 2.0))

        print("[*] Podciągam ekran w dół, żeby zobaczyć pole Miasto...")
        for _ in range(random.randint(15, 25)):
            await page.mouse.wheel(0, random.randint(10, 20))
            await asyncio.sleep(random.uniform(0.01, 0.03))
        await asyncio.sleep(random.uniform(1.0, 2.0))

        print("[*] Wypełniam Miasto...")
        await human_type(page, "#dwfrm_registrationcontact_city", dane["miasto"], mistake_rate=0.15, typing_speed=(200, 450))
        await asyncio.sleep(random.uniform(1.0, 2.0))

        print("[*] Podciągam ekran w dół, żeby zobaczyć pole Telefonu...")
        for _ in range(random.randint(20, 30)):
            await page.mouse.wheel(0, random.randint(15, 25))
            await asyncio.sleep(random.uniform(0.01, 0.03))
        await asyncio.sleep(random.uniform(1.5, 3.0)) 

        print("[*] Wypełniam Numer Telefonu...")
        await human_type(page, "#dwfrm_registrationcontact_mobileNumber", dane["telefon"], typing_speed=(250, 500))
        await asyncio.sleep(random.uniform(1.5, 3.0))

        print("[*] Szukam przycisku Dalej i w niego klikam...")
        await smooth_click_element(page, 'button[type="submit"]') 

        print("[*] Formularz wysłany. Czekam 20 sekund przed zamknięciem profilu...")
        for _ in range(4):
            await smooth_mouse_and_click(page, actions=1)
            await asyncio.sleep(5)

    except Exception as e:
        print(f"[!] Błąd wykonania profilu: {e}")